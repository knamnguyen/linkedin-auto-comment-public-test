(function(){try{console.log("content script loaded")}catch(o){console.error(o)}let c=!1,p=new Set,h=!1;chrome.runtime.onMessage.addListener((o,t,r)=>{if(console.log("Content script received message:",o),o.action==="startNewCommentingFlow")E(o.scrollDuration,o.commentDelay,o.maxPosts,o.spectatorMode,o.styleGuide,o.apiKey),r({success:!0});else if(o.action==="stopCommentingFlow")console.log("Received stop signal - stopping commenting flow"),c=!1,r({success:!0});else if(o.action==="openrouter_error"){console.group("🚨 OPENROUTER API ERROR - WHY FALLBACK COMMENT WAS USED"),console.error("🔥 OpenRouter API Error Message:",o.error.message),console.error("🔥 Error Type:",o.error.name),console.error("🔥 API Key Status:",o.error.apiKey),console.error("🔥 Style Guide Status:",o.error.styleGuide),console.error("🔥 Post Content Length:",o.error.postContentLength,"characters"),console.error("🔥 Timestamp:",o.error.timestamp),o.error.stack&&console.error("🔥 Stack Trace:",o.error.stack),console.error('🔥 This is why the comment defaulted to "Great post! Thanks for sharing."'),console.groupEnd();const e=document.createElement("div");e.style.cssText=`
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      background: #ff4444;
      color: white;
      border: 3px solid #fff;
      padding: 20px;
      border-radius: 12px;
      z-index: 99999;
      max-width: 500px;
      font-family: Arial, sans-serif;
      font-size: 14px;
      box-shadow: 0 8px 24px rgba(0,0,0,0.3);
      text-align: center;
    `,e.innerHTML=`
      <div style="font-weight: bold; font-size: 18px; margin-bottom: 12px;">
        🚨 OpenRouter API Error Detected
      </div>
      <div style="margin-bottom: 10px; font-size: 16px;">
        ${o.error.message}
      </div>
      <div style="font-size: 12px; margin-bottom: 15px; opacity: 0.9;">
        This is why the comment defaulted to "Great post! Thanks for sharing."
      </div>
      <div style="font-size: 12px; margin-bottom: 15px; opacity: 0.9;">
        API Key: ${o.error.apiKey} | Content Length: ${o.error.postContentLength} chars
      </div>
      <button onclick="this.parentElement.remove()" style="
        background: white;
        color: #ff4444;
        border: none;
        padding: 8px 16px;
        border-radius: 6px;
        cursor: pointer;
        font-weight: bold;
        font-size: 12px;
      ">Close & Check Console</button>
    `,document.body.appendChild(e),setTimeout(()=>{e.parentElement&&e.remove()},15e3)}else if(o.action==="statusUpdate"&&o.error){console.group("🚨 LinkedIn Auto Commenter Error Details"),console.error("Error Message:",o.error.message),o.error.status&&console.error("HTTP Status:",o.error.status,"-",o.error.statusText),o.error.body&&console.error("API Response Body:",o.error.body),o.error.headers&&console.error("Response Headers:",o.error.headers),console.error("API Key Status:",o.error.apiKey||"Unknown"),console.error("Style Guide Status:",o.error.styleGuide||"Unknown"),o.error.postContentLength!==void 0&&console.error("Post Content Length:",o.error.postContentLength,"characters"),o.error.stack&&console.error("Stack Trace:",o.error.stack),o.error.data&&console.error("Additional Data:",o.error.data),console.groupEnd();const e=document.createElement("div");e.style.cssText=`
      position: fixed;
      top: 20px;
      right: 20px;
      background: #fee;
      border: 2px solid #f00;
      padding: 15px;
      border-radius: 8px;
      z-index: 10000;
      max-width: 400px;
      font-family: Arial, sans-serif;
      font-size: 12px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    `,e.innerHTML=`
      <div style="font-weight: bold; color: #d00; margin-bottom: 8px;">
        🚨 LinkedIn Auto Commenter Error
      </div>
      <div style="color: #800; margin-bottom: 5px;">
        ${o.error.message||"Unknown error occurred"}
      </div>
      ${o.error.status?`<div style="color: #600; font-size: 11px;">HTTP ${o.error.status}: ${o.error.statusText}</div>`:""}
      <div style="color: #600; font-size: 11px; margin-top: 5px;">
        Check console for full details (F12)
      </div>
      <button onclick="this.parentElement.remove()" style="
        background: #d00;
        color: white;
        border: none;
        padding: 4px 8px;
        border-radius: 4px;
        cursor: pointer;
        font-size: 10px;
        margin-top: 8px;
      ">Close</button>
    `,document.body.appendChild(e),setTimeout(()=>{e.parentElement&&e.remove()},1e4)}});function u(){return new Date().toDateString()}async function y(){const t=`commented_authors_${u()}`;return new Promise(r=>{chrome.storage.local.get([t],e=>{const n=e[t]||[];r(new Set(n))})})}async function b(o){const t=u(),r=`commented_authors_${t}`;return new Promise(e=>{chrome.storage.local.get([r],n=>{const l=n[r]||[];l.includes(o)?e():(l.push(o),chrome.storage.local.set({[r]:l},()=>{console.log(`Saved commented author: ${o} for ${t}`),e()}))})})}async function C(){const t=`comments_today_${u()}`;return new Promise(r=>{chrome.storage.local.get([t,"totalAllTimeComments"],e=>{const n=e[t]||0,l=e.totalAllTimeComments||0,s=n+1,i=l+1;chrome.storage.local.set({[t]:s,totalAllTimeComments:i},()=>{console.log(`Updated counts - Today: ${s}, All-time: ${i}`),chrome.runtime.sendMessage({action:"realTimeCountUpdate",todayCount:s,allTimeCount:i}),r()})})})}async function E(o,t,r,e,n,l){c=!0,h=e,p=await y(),console.log(`Loaded ${p.size} already commented authors for today`);try{if(console.log(`Starting new commenting flow with max ${r} posts in ${e?"spectator":"background"} mode...`),await w(o),!c){console.log("Commenting stopped during scroll phase");return}if(console.log("Scrolling back to top..."),window.scrollTo({top:0,behavior:"smooth"}),await m(2e3),!c){console.log("Commenting stopped during scroll to top");return}await S(t,r),c&&chrome.runtime.sendMessage({action:"commentingCompleted"})}catch(s){console.error("Error in new commenting flow:",s),c=!1}}async function w(o){console.log(`Scrolling feed for ${o} seconds to load posts...`);const r=Date.now()+o*1e3;for(;Date.now()<r&&c;){if(!c){console.log("Stopping scroll due to stop signal");break}if(window.scrollTo(0,document.body.scrollHeight),await m(500),!c){console.log("Stopping scroll due to stop signal after wait");break}const e=document.body.scrollHeight;await m(1e3);const n=document.body.scrollHeight;e===n&&console.log("No new content detected, continuing to scroll...")}console.log("Finished scrolling to load posts")}async function S(o,t){console.log(`Starting to process posts on feed (max ${t} posts) in ${h?"spectator":"background"} mode...`);const r=document.querySelectorAll(".feed-shared-update-v2__control-menu-container");console.log(`Found ${r.length} posts to process`);let e=0;for(let n=0;n<r.length&&c&&e<t;n++){if(!c){console.log("Stopping post processing due to stop signal");break}const l=r[n];try{if(console.log(`Processing post ${n+1}/${r.length} (commented: ${e}/${t})`),l.scrollIntoView({behavior:"smooth",block:"center"}),await m(1e3),!c){console.log("Stopping due to stop signal after scroll to post");break}const s=x(l);if(!s){console.log(`Skipping post ${n+1} - could not extract author info`);continue}if(p.has(s.name)){console.log(`Skipping post ${n+1} - already commented on ${s.name} today`);continue}const i=k(l);if(!i){console.log(`Skipping post ${n+1} - could not extract post content`);continue}if(console.log(`Post content: ${i.substring(0,100)}...`),!c){console.log("Stopping due to stop signal before comment generation");break}const a=await T(i);if(!a){console.log(`❌ Skipping post ${n+1} - could not generate comment`);continue}if(console.log(`✅ Generated comment for post ${n+1}:`,a),!c){console.log("Stopping due to stop signal before posting comment");break}if(console.log(`📝 Attempting to post comment on post ${n+1} by ${s.name}...`),await A(l,a)){if(e++,p.add(s.name),await b(s.name),await C(),console.log(`🎉 Successfully posted comment ${e}/${t} on post by ${s.name}`),console.group("📊 Progress Update"),console.log(`Comments posted this session: ${e}/${t}`),console.log("Authors commented on today:",Array.from(p)),console.groupEnd(),chrome.runtime.sendMessage({action:"updateCommentCount",count:e,status:`Posted comment ${e}/${t} on post by ${s.name}`}),e>=t){console.log(`Reached maximum posts limit (${t}). Stopping...`);break}if(n<r.length-1&&e<t){console.log(`Waiting ${o} seconds before next comment...`);const g=Math.ceil(o);for(let f=0;f<g&&c;f++)if(await m(1e3),!c){console.log("Stopping during comment delay due to stop signal");break}}}else console.log(`Failed to post comment on post ${n+1} by ${s.name}`)}catch(s){console.error(`Error processing post ${n+1}:`,s)}}console.log(`Completed processing posts. Posted ${e}/${t} comments total.`)}function x(o){try{const t=o.querySelector(".update-components-actor__container");if(!t)return console.log("Author container not found"),null;const r=['.update-components-actor__title span[dir="ltr"] span[aria-hidden="true"]','.update-components-actor__title span[aria-hidden="true"]',".update-components-actor__title",".update-components-actor__name"];for(const e of r){const n=t.querySelector(e);if(n&&n.textContent){const l=n.textContent.replace(/<!---->/g,"").trim().split("•")[0].trim();if(l)return console.log(`Extracted author name: ${l}`),{name:l}}}return console.log("Could not extract author name"),null}catch(t){return console.error("Error extracting author info:",t),null}}function k(o){try{let r=function(l){let s="";return l.childNodes.forEach(i=>{var a;i.nodeType===Node.TEXT_NODE?s+=((a=i.textContent)==null?void 0:a.trim())+" ":i.nodeType===Node.ELEMENT_NODE&&(s+=r(i))}),s};var t=r;const e=o.querySelector(".fie-impression-container");if(!e)return console.log("Content container not found"),"";const n=r(e).replace(/\s+/g," ").trim();return console.log(`Extracted post content: ${n.substring(0,100)}...`),n}catch(r){return console.error("Error extracting post content:",r),""}}async function T(o){return new Promise(t=>{console.log("🤖 Requesting comment generation for post content:",o.substring(0,200)+"...");const r=setTimeout(()=>{console.error("⏰ FALLBACK REASON: Comment generation timed out after 30 seconds"),console.error("⏰ TIMEOUT - No response from OpenRouter API within 30 seconds"),t("Great post! Thanks for sharing.")},3e4);chrome.runtime.sendMessage({action:"generateComment",postContent:o},e=>{clearTimeout(r),chrome.runtime.lastError?(console.error("💥 FALLBACK REASON: Chrome runtime error during comment generation"),console.error("💥 CHROME ERROR:",chrome.runtime.lastError),console.error("💥 This usually means the background script crashed or message passing failed"),t("Great post! Thanks for sharing.")):e?e.comment?e.comment==="Great post! Thanks for sharing."?(console.error("🚨 FALLBACK REASON: Background script returned the default fallback comment"),console.error("🚨 This means OpenRouter API failed and background script used fallback"),e.error?(console.group("🔥 OPENROUTER ERROR DETAILS FROM RESPONSE"),console.error("🔥 Error Message:",e.error.message),console.error("🔥 Error Type:",e.error.name),console.error("🔥 API Key Status:",e.error.apiKey),console.error("🔥 Style Guide Status:",e.error.styleGuide),console.error("🔥 Post Content Length:",e.error.postContentLength,"characters"),e.error.stack&&console.error("🔥 Stack Trace:",e.error.stack),console.groupEnd()):console.error("🚨 No error details provided - check background script console"),t(e.comment)):(console.log("✅ Successfully received generated comment:",e.comment.substring(0,100)+"..."),t(e.comment)):(console.error("⚠️ FALLBACK REASON: Response received but no comment field"),console.error("⚠️ INVALID RESPONSE STRUCTURE:",e),console.error("⚠️ Expected response.comment but got:",Object.keys(e)),t("Great post! Thanks for sharing.")):(console.error("❌ FALLBACK REASON: No response received from background script"),console.error("❌ RESPONSE NULL - Background script may have failed silently"),t("Great post! Thanks for sharing."))})})}async function A(o,t){try{if(console.group("📝 Comment Posting Process"),console.log("Starting to post comment:",t.substring(0,100)+"..."),!c)return console.log("❌ Stopping comment posting due to stop signal"),console.groupEnd(),!1;console.log("🔍 Looking for comment button...");const r=o.querySelector('button[aria-label="Comment"]');if(!r)return console.error("❌ Comment button not found"),console.groupEnd(),!1;if(console.log("👆 Clicking comment button..."),r.click(),console.log("⏳ Waiting for comment editor to appear..."),await m(2e3),!c)return console.log("❌ Stopping during comment editor wait due to stop signal"),console.groupEnd(),!1;console.log("🔍 Looking for comment editor...");const e=o.querySelector(".comments-comment-box-comment__text-editor");if(!e)return console.error("❌ Comment editor not found"),console.groupEnd(),!1;console.log("🔍 Looking for editable field...");const n=e.querySelector('div[contenteditable="true"]');if(!n)return console.error("❌ Editable field not found"),console.groupEnd(),!1;if(console.log("✅ Found editable field, inputting comment..."),!c)return console.log("❌ Stopping during comment input due to stop signal"),console.groupEnd(),!1;n.focus(),n.click(),n.innerHTML="",t.split(`
`).forEach(d=>{const g=document.createElement("p");d===""?g.appendChild(document.createElement("br")):g.textContent=d,n.appendChild(g)});const s=window.getSelection();if(s){const d=document.createRange();n.lastChild?d.setStartAfter(n.lastChild):d.selectNodeContents(n),d.collapse(!0),s.removeAllRanges(),s.addRange(d)}n.focus();const i=new Event("input",{bubbles:!0,cancelable:!0});if(n.dispatchEvent(i),console.log("✅ Comment text inputted successfully"),console.log("⏳ Waiting for submit button to become enabled..."),await m(1e3),!c)return console.log("❌ Stopping during submit button wait due to stop signal"),console.groupEnd(),!1;console.log("🔍 Looking for submit button...");const a=o.querySelector(".comments-comment-box__submit-button--cr");return!a||a.disabled?(console.error("❌ Submit button not found or disabled"),console.groupEnd(),!1):(console.log("🚀 Clicking submit button..."),a.click(),console.log("⏳ Waiting for comment to be posted..."),await m(2e3),console.log("🎉 Comment posted successfully"),console.groupEnd(),!0)}catch(r){return console.error("💥 Error posting comment:",r),console.groupEnd(),!1}}function m(o){return new Promise(t=>setTimeout(t,o))}console.log("LinkedIn Auto Commenter content script loaded - New Single Mode");
})()